import server

def main():
     server.serverCalistir()


if __name__ == '__main__':
     main()