import socket as s
port=5423
def serverCalistir():
   try:
    server=s.socket(family=s.AF_INET,type=s.SOCK_STREAM)
    server.bind(('192.168.1.3',port))
    server.listen(8)
    print("Beklemedeyiz hacılar!")
    client,adr =server.accept()
    print(adr, 'bağlandı')
    server.close()
    client.close()
   except s.error as msg:
      print(msg)


