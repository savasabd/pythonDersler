import socket as s
port=5423
try:
 client=s.socket(family=s.AF_INET,type=s.SOCK_STREAM)
 client.connect(('192.168.1.3',port))
 print("Bağlandık hacı!")
 client.close()
 client.close()
except s.error as msg:
    print(msg)