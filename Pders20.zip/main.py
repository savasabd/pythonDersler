import os
class program:

     @staticmethod
     def myprint(s1):
         f=open("dosya.sav","a")
         print(s1,file=f)
         f.close();


     @staticmethod
     def run():
         f=open("kadi.txt","r");
         s1=f.read()
         f.close();
         if (s1=="") :
             str1=input("Lütfen kullanıcı adınızı giriniz: ")
             f=open("kadi.txt","w")
             f.write(str1)
             f.close()

             print("Hoş geldiniz ",str1," !")

         else:
             print("Hoş geldiniz ", s1, "!")
     @staticmethod
     def run2():
      s1=""
      while True:
        if (s1=="_q"):
            break;
        s2=input("_")
        program.myprint(s2)

if __name__=="__main__":
    program.run2()



