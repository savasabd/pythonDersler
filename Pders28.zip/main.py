#+-*/


dongu=True;
class Program:

    @staticmethod
    def Toplama(a,b):
        return a+b;
    @staticmethod
    def Cikarma(a,b):
        return a - b;
    @staticmethod
    def Carpma(a,b):
        return a*b;
    @staticmethod
    def Bolme(a,b):
        return a/b;

    @staticmethod
    def Bitir(a,b):
        global dongu;
        dongu=False;
        return  "Bizi tercih ettiğiniz için teşekürler! ";

    @staticmethod
    def main():
        global dongu;
        while dongu :
         liste=[Program.Toplama,Program.Cikarma,Program.Carpma,Program.Bolme,Program.Bitir];
         try:
           print("""
           0.Toplama
           1.Çıkarma
           2.Çarpma
           3.Bölme  
           """)
           ilk = int(input("İlk sayıyı giriniz: "))
           ikinci = int(input("İkinci sayıyı giriniz: "))
           secim=int(input("Yukardaki işlemlerden birini seçiniz yada çıkmak için 4'e basınız! "))

           print("Sonuç: ",liste[secim](ilk,ikinci))


         except:
           print("Bir Sorun Oluştu")


def sizyapin(str):
    eval("print("+str+")")





if __name__ == '__main__':
    sizyapin(input("Bir işlem giriniz:"))
